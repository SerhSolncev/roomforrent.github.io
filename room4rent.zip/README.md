## Install

1. run npm install from /
2  npm run dev - develop mode
3. npm run prod - build in dist

## Scripts and other
1. There is a main js file - common.js, everything you need can be written in it.
2. Dynamic import is configured here, that is, the module will be loaded only if it is needed on the page, how to work with it (accordion example):
2.1 - copy the accordion folder, change the name to the one we need, 
"wrapInit" remains in the index file + import from the accordion.
 In the accordion file, we create a function with the same name and export it, everything we need is written in it.
  Element in this file is the block on which the module init takes place on the page,
   it must be specified in the js>dmi>index.js folder, following the example of the others:
filter : here is the selector by which we define the module (element ), for example, the data-accordion attribute
importFn: file path
and be sure to add the class "js-dmi" to the element
would be like this: <div class="js-dmi" data-accordion>
All modules are ready! but you can just use common.js
After npm run prod it all goes into the dist folder in scripts
3. in the pug folder, page markup, after the build it falls into the dist as html
4. If you are doing something here, push and pull for actual version
5. If you have any questions, please contact

